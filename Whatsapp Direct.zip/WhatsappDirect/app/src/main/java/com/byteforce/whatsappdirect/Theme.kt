package com.byteforce.whatsappdirect

import android.app.Application

class Theme:Application() {

}